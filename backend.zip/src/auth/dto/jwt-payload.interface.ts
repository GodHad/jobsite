export interface JwtPayoad {
  id: number;
}
