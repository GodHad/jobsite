import { IsNumber, IsString } from 'class-validator';
import { Type } from 'class-transformer';

export class GetPositionsFilterDto {
  jobTitle?: string;
  publishDate?: string;
  companySize?: string;
  jobLocation?: string;
  companyIndustry?: string;
  @IsNumber()
  @Type(()=>Number)
  page_size: number;
  @IsNumber()
  @Type(()=>Number)
  page: number;
}