import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import * as config from 'config';
const dbConfig = config.get('db');
const isProduction = process.env.NODE_ENV==="production"||process.env.DB_NODE_ENV==="production";
export const typeOrmConfig: TypeOrmModuleOptions = {
  type: 'postgres',
  host: isProduction? process.env.DB_HOST : dbConfig.host,
  port: isProduction? Number(process.env.DB_PORT): dbConfig.port,
  username: isProduction? process.env.DB_USERNAME : dbConfig.username,
  password: isProduction? process.env.DB_PASSWORD : dbConfig.password,
  database: isProduction? process.env.DB_NAME : dbConfig.name,
  entities: [__dirname + '/../src/**/*.entity.{js,ts}'],
  synchronize: process.env.TYPEORM_SYNC == 'true',
  migrations: ['migration/*.{js,ts}'],
  cli: { migrationsDir: 'migration' },
  ssl: false

  // connectTimeoutMS: 1500,
};
