export default function AdminJobView(){
    return (
        <></>
    )
}