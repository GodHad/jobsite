import Document, { Html, Head, Main, NextScript } from 'next/document'
import * as React from "react";

import Script from "next/script"
class MyDocument extends Document {
  static async getInitialProps(ctx) {
    const initialProps = await Document.getInitialProps(ctx)
    return { ...initialProps }
  }

  render() {
    return (
      <Html>
        <Head>
            <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>
            <link href="/assets/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css"/>
            <link href="/assets/css/style.bundle.css" rel="stylesheet" type="text/css"/>
            <link href="/assets/css/global-styles.css" rel="stylesheet" type="text/css"/>
        </Head>

          <body>


            <Script src="/assets/plugins/global/plugins.bundle.js"></Script>
            <Script src="/assets/js/scripts.bundle.js"></Script>





            <Main />
            <NextScript />


        </body>
      </Html>
    )
  }
}

export default MyDocument