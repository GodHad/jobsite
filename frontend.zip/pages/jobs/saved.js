export default function SavedApplications(){
    return (
        <></>
    )
}