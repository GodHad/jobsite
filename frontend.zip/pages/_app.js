import 'notiflix/dist/notiflix-3.0.1.min.css'
import config from "../config/default.js"

const serverUrl = config.domain.server
import {GetUser} from "../components/CustomHooks/GetUser";
import {useEffect, useState} from "react";
import 'reactjs-popup/dist/index.css';
import {useRouter} from "next/router";

import {Provider} from "react-redux";
import {store} from "../state/store";


const AppComponent = ({Component, pageProps}) => {
    const router = useRouter()
    const {query} = router;
    const [user, setUser] = useState(null)


    async function userChecks() {

        const userData = await GetUser("/");
        if (router.pathname !== '/sign-in' && router.pathname !== '/jobs' && !userData && !router.pathname.includes('jobs/')) return router.push("/jobs")
        setUser(userData)
    }


    useEffect(() => {
        userChecks()
    }, [])


    return (
        <Provider store={store}>

            <div>
                <Component {...pageProps} user={user} serverUrl={serverUrl} query={router.query} userChecks={userChecks}
                           router={router} pageTitle={"Job Board"}/>
            </div>
        </Provider>

    )
};

AppComponent.getInitialProps = async appContext => {
    let pageProps = {};
    if (appContext.Component.getInitialProps) {
        pageProps = await appContext.Component.getInitialProps(appContext.ctx);
    }
    ;
    return {
        pageProps
    };
};

export default AppComponent;