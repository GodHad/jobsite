module.exports = {
    reactStrictMode: true,
    // async redirects() {
    //   return [
    //     {
    //       source: '/',
    //       destination: '/jobs',
    //       permanent: true,
    //     },
    //   ]
    // },
}